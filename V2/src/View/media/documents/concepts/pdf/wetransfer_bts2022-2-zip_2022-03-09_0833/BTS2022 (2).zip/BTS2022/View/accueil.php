<div class="container">
	<div class="row">
		<div class="col-lg-8">
			
				<h1>Exemple CRUD pour des Personnes associées à des Films</h1>
				<h2>Le MCD </h2>
				<img class="img-fluid" src="./view/mcd.png">
				
		</div>	
		<div class="col-lg-8">	
				<h2>Le diagramme de classe </h2>
				<img class="img-fluid" src="./view/diagClasse.png" height="300">
				<h2>Organisation des fichiers </h2>
				<img class="img-fluid" src="./view/organisationFichiers.png" height="300">
				<img class="img-fluid" src="./view/blank.png" height="300">
				
		</div>
	</div>
</div>