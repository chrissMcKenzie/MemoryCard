<style>
    * {
        /* position: static; */
        margin: 0;
        padding: 0;
        text-decoration: none;
        list-style-type: none;
    }

    html {
        width: 100%;
        height: 100%;
        display: block;
    }

    header {
        z-index: 500;
        margin-top: 0%;
        padding: 1%;
        background-color: white;
        width: 100%;
        height: 7%;
        color: black;
        text-align: center;
    }

    footer {
        z-index: 500;
        position: fixed;
        bottom: 0%;
        margin-bottom: 0px;
        padding: 1%;
        background-color: white;
        width: 100%;
        height: 12px;
        color: black;
        text-align: center;
    }
</style>

<header>
    <h1>phpPOO</h1>
</header>

<footer>
    <h2>2022 CopyRight</h2>
</footer>