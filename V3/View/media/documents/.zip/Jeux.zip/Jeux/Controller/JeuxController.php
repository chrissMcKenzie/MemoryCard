<?php

class JeuxController
{

    public function render()
    {
    }

    public function index()
    {
    }

    public function JeuxView()
    {
    }
}
