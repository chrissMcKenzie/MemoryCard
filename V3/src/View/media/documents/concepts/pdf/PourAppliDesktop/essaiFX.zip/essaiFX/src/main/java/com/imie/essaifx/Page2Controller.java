package com.imie.essaifx;

import javafx.event.ActionEvent;
import javafx.scene.control.TextArea;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyEvent;

import java.util.Locale;

public class Page2Controller {
    public TextArea txtInput;
    private boolean isMajuscule=false;

    public void setIsMajuscule(boolean isMajuscule) {
        this.isMajuscule = isMajuscule;
    }


    public void OnAction(ActionEvent actionEvent) {
        if (this.isMajuscule)
            txtInput.setText(txtInput.getText().toUpperCase());
        else
            txtInput.setText(txtInput.getText().toLowerCase());
    }

}
