module com.imie.essaifx {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires org.kordamp.bootstrapfx.core;

    opens com.imie.essaifx to javafx.fxml;
    exports com.imie.essaifx;
}